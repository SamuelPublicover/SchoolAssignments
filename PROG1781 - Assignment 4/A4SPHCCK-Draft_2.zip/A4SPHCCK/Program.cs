﻿/* Program ID: A4SPHCCK
 * 
 * Purpose: To exemplify knowledge of arrays
 * 
 * Revision History
 *  Created 2020-11-11 by Sam P, Hulya C, Connie K
 */




using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A4SPHCCK
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare Variables
            string[] shirtSizes = new string[4] { "1", "2", "3", "4" };
            string[] brandSPHCCK = new string[3];
            string[] tShirtCompleted = new string[12] {"NONE", "NONE", "NONE", "NONE", "NONE", "NONE", "NONE", "NONE", "NONE", "NONE", "NONE", "NONE"};
            int menuOption = 0;
            bool keepGoing = true;
            bool itemDelete = true;
            bool loopOption = true;
            string userSelection = "";
            string brand = "";
            int optionThreeInt = 0;
            string inputBrandString = "";
            string inputSizeString = "";
            string tshirtString = "";
            int i = 0;
            int a = 0;
            bool tShirtFoundBool = true;
            bool tShirtSavedBool = true;
            bool exitProgram = false;
            bool tShirtExistsBool = false;


            //Get store name and three brands
            //Use a 'for' loop
            Console.WriteLine("Please enter the three brands your store carries:");
            Console.Write("Brand 1:");
            brandSPHCCK[0] = Console.ReadLine();
            Console.Write("Brand 2:");
            brandSPHCCK[1] = Console.ReadLine();
            Console.Write("Brand 3:");
            brandSPHCCK[2] = Console.ReadLine();

            do //Display Menu
            {
                Console.WriteLine("Please choose from the following: ");
                Console.WriteLine("1. Add new T-Shirt details (Brand Name & Size)");
                Console.WriteLine("2. Edit existing T-Shirt details (Brand Name & Size)");
                Console.WriteLine("3. Display all T-Shirts in store (display the Brand Name & Size");
                Console.WriteLine("4. Delete T-Shirt Info");
                Console.WriteLine("5. Exit the program ");
                menuOption = int.Parse(Console.ReadLine());


                //Menu option 1 Selected
                if (menuOption == 1)
                {
                    //reset variables 
                    tShirtFoundBool = true;
                    tShirtSavedBool = true;
                    tShirtExistsBool = false;

                    //Create a New T-Shirt (Input brand name and size)
                    //Loop Option 1 until performed correctly (a new T-Shirt is added if able)

                    //Enter the T-Shirt's Brand
                    Console.WriteLine();
                    Console.WriteLine("Which brand is this new T-Shirt:");
                    Console.WriteLine("- " + brandSPHCCK[0]);
                    Console.WriteLine("- " + brandSPHCCK[1]);
                    Console.WriteLine("- " + brandSPHCCK[2]);
                    inputBrandString = Console.ReadLine();
                    do
                    {
                        if (inputBrandString == brandSPHCCK[0] || inputBrandString == brandSPHCCK[1] || inputBrandString == brandSPHCCK[2])
                        {
                            keepGoing = false;
                        }
                        else
                        {
                            keepGoing = true;
                            Console.WriteLine("Brand does not exist, please enter one of the provided brands.");
                        }
                    } while (keepGoing);

                    //Get Size
                    Console.WriteLine("What is the size of the shirt? (Enter a digit from 1-4)");
                    Console.WriteLine(shirtSizes[0] + ": Small");
                    Console.WriteLine(shirtSizes[1] + ": Medium");
                    Console.WriteLine(shirtSizes[2] + ": Large");
                    Console.WriteLine(shirtSizes[3] + ": X-Large");
                    inputSizeString = Console.ReadLine();

                    do  //Loop until proper size is entered 
                    {
                        if (inputSizeString == "1" || inputSizeString == "2" || inputSizeString == "3" || inputSizeString == "4")
                        {
                            keepGoing = false;
                        }
                        else
                        {
                            Console.WriteLine("Please enter a numeric value from 1-4");
                            keepGoing = true;
                        }

                    } while (keepGoing);

                    //conjugate brand and size, with "-" in between
                    tshirtString = inputBrandString + "-" + inputSizeString;

                    i = 0;

                    tShirtExistsBool = false;

                    //Sift through completed/stored T-Shirt's array to see if entered T-Shirt already exists
                    do
                    {
                        if (tShirtCompleted[i] == tshirtString)
                        {
                                    
                            tShirtExistsBool = true;
                            Console.WriteLine("T-Shirt has already been stored in spot #" + i);
                        }
                                
                        i++;

                    } while (i < 12 && !(tShirtExistsBool));


                    i = 0;
                    tShirtSavedBool = false;
                    //Sift through T-Shirts to find an empty spot IF the T-Shirt doesn't already exist
                    if (!tShirtExistsBool)
                    {
                        do
                        {
                            if (tShirtCompleted[i] == "NONE")
                            {
                                tShirtCompleted[i] = tshirtString;
                                tShirtSavedBool = true;
                                Console.WriteLine("T-Shirt: " + tshirtString + ", has been saved in spot #" + (i+1));
                            }
                            i++;

                        } while (i < 12 && !(tShirtSavedBool));
                    }
                    else
                    //Tell user to go back to menu and delete a shirt if desired
                    {
                        Console.WriteLine("Please enter a t-shirt that doesn't already exist, or delete the previously saved shirt.");
                    }

                    //If the do loop has gone thorugh 12 iterations and did not find an empty T-Shirt value, inventory is full.
                    if (!tShirtExistsBool && !tShirtSavedBool)
                    {
                        Console.WriteLine("Inventory Full, Please delete a saved shirt before creating a new entry.");
                    }

                }



                else if (menuOption == 2)
                {
                    //Edit existing details of a saved shirt; loop until executed properly
                    do
                    {
                        //Specify which shirt you'd like the find
                        do
                        {
                            //Enter the T-Shirt's Brand; loop until entered correctly
                            Console.WriteLine();
                            Console.WriteLine("Which brand is this new T-Shirt:");
                            Console.WriteLine("- " + brandSPHCCK[0]);
                            Console.WriteLine("- " + brandSPHCCK[1]);
                            Console.WriteLine("- " + brandSPHCCK[2]);
                            inputBrandString = Console.ReadLine();
                            if (inputBrandString == brandSPHCCK[0] || inputBrandString == brandSPHCCK[1] || inputBrandString == brandSPHCCK[2])
                            {
                                keepGoing = false;
                            }
                            else
                            {
                                keepGoing = true;
                                Console.WriteLine("Brand does not exist, please enter one of the provided brands.");

                            }
                        } while (keepGoing);

                        //Loop until proper size is entered correctly
                        do
                        {
                            Console.WriteLine("What is the size of the shirt? (Enter a digit from 1-4)");
                            Console.WriteLine(shirtSizes[0] + ": Small");
                            Console.WriteLine(shirtSizes[1] + ": Medium");
                            Console.WriteLine(shirtSizes[2] + ": Large");
                            Console.WriteLine(shirtSizes[3] + ": X-Large");
                            inputSizeString = Console.ReadLine();
                            if (inputSizeString == "1" || inputSizeString == "2" || inputSizeString == "3" || inputSizeString == "4")
                            {
                                keepGoing = false;
                            }
                            else
                            {
                                Console.WriteLine("Please enter a numeric value from 1-4");
                                keepGoing = true;
                            }

                        } while (keepGoing);


                        tshirtString = inputBrandString + "-" + inputSizeString;
                        tShirtFoundBool = false;
                        i = 0;

                        //Loop through T-Shirt's to see if T-Shirt entere actually exists
                        do
                        {
                            if (tShirtCompleted[i] == tshirtString)
                            {
                                tShirtFoundBool = true;
                                i = a;
                            }

                            i++;
                        } while (i < 20 && !(tShirtFoundBool));

                        //If the T-Shirt exists, ask user what they'd like to replace it with
                        if (tShirtFoundBool)
                        {
                            Console.WriteLine("T-Shirt Information Found in spot #" + a);
                            //Ask for what to edit
                            //This should be the correct tShirt
                            Console.WriteLine(tShirtCompleted[a]);
                            Console.WriteLine("What brand would you like this T-Shirt to be?");
                            Console.WriteLine("- " + brandSPHCCK[0]);
                            Console.WriteLine("- " + brandSPHCCK[1]);
                            Console.WriteLine("- " + brandSPHCCK[2]);
                            inputBrandString = Console.ReadLine();
                            Console.WriteLine("What size would you like this T-shirt to be?");
                            Console.WriteLine(shirtSizes[0] + ": Small");
                            Console.WriteLine(shirtSizes[1] + ": Medium");
                            Console.WriteLine(shirtSizes[2] + ": Large");
                            Console.WriteLine(shirtSizes[3] + ": X-Large");
                            inputSizeString = Console.ReadLine();
                            tShirtCompleted[a] = inputBrandString + "-" + inputSizeString;
                            Console.WriteLine("T-Shirt Saved as:" + tShirtCompleted[a] + ", in spot #" + a);

                        }
                        //If T-Shirt isn't found, tell user to create one back at the menu
                        else
                        {
                            Console.WriteLine("T-Shirt Record Not Found, no T-shirt's with those specifications currently exist within the system.");
                        }
                    } while (loopOption);
                }

                //Menu Option #3: Display all completed/saved T-Shirts in the system
                else if (menuOption == 3)

                {
                    for (int b = 0; b < tShirtCompleted.Length; b++)
                    {
                        Console.WriteLine("Shirt #" + (b+1) + ": "+ tShirtCompleted[b]);
                    }
                    keepGoing = true;
                    //Display all t-shirts in store
                }


                else if (menuOption == 4)
                {
                    //do
                    //{
                    //    Console.WriteLine("Please enter a brand and size you wish to delete (eg: brand-4): ");
                    //    if (brandSPHCCK[0] && shirtSizes[0, 1, 2, 3])
                    //    {
                    //        Console.WriteLine("Are you sure you want to delete this item? Hit Y or N");
                    //        if (userSelection == "Y")
                    //        {
                    //            Console.WriteLine("You have deleted an entry");
                    //            itemDelete = true;
                    //        }
                    //        else if (userSelection == "N")
                    //        {

                    //        }
                    //    }
                    //    else if (!brandSPHCCK && !shirtSizes[0, 1, 2, 3])
                    //    {
                    //        Console.WriteLine("There are no records of this item. Please try again.");
                    //        itemDelete = false;
                    //    }
                    //} while (!itemDelete);
                }

                else
                {
                    //Exit Program
                    exitProgram = true;
                    keepGoing = false;
                }
                
            } while (!exitProgram);
            Console.ReadLine();
        }
    }
}
